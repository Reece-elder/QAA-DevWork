# Lesson 
Go through Slides for Lists 

# Tutorial
Go through demo.py file

# Lab
Complete 'Lists Lab'