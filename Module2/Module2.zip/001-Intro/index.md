# Lesson 
Go through Slides

# Tutorial
Go through demo.py file

# Lab
Complete 'Python Programming Basics Lab'