# Lesson
Go through slides of inbuilt functions

# Tutorial
No need for a tutorial, slide has all of the data

# Demo
Inbuilt functions Lab