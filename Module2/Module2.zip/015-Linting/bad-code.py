from random import *
dicerollernumber = 6,
def rolllotsofdice():
   return randint(1,6)
print(rolllotsofdice())
def rolllotsofdice2():
   return randint(1,10,)
def rollcustonnumbersss(numberone, numbertwo,):
   importantvariable = "hello"
   return randint(numberone, numbertwo)
def checkrolls():
    if rolllotsofdice2() >= 6:
        return "big number!!!"
    else:
       return "small number :( "
    return "other return.."
checlrollsvar= checkrolls()
print(checlrollsvar)
longvarname = "this is a really long variable that is integral to the flow of the code, if this variable is to become any shorter the code will simply fail as this is a fundamental piece of code for the really important and really resilient code base.. how many chars now??"