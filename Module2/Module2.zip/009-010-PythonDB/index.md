# Lesson
Go through slides of Database

# Tutorial
Access Microsoft Server with GoToMyPC, go through basics of SQL within Microsft SQL Server
 
Go through demo.py with names.txt file added

# Demo
FileIO Lab, transfer .csv file over