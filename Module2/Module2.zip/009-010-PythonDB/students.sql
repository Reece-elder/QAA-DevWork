CREATE TABLE IF NOT EXISTS students (
    first_name VARCHAR(40),
    class_name VARCHAR(30),
    age INT
);

INSERT INTO students VALUES('John', 'Product Design', 16),('Lira', 'Geography', 17);