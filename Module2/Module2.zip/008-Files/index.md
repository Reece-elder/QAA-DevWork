# Lesson
Go through slides of FileIO

# Tutorial
Go through demo.py with names.txt file added

# Demo
FileIO Lab, transfer .csv file over