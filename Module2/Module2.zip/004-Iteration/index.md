# Lesson 
Go through Slides for Iteration

# Tutorial
Go through demo.py file

# Lab
Complete 'Iteration Lab'