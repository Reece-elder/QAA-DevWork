# Lesson
Go through slides of custom functions

# Tutorial
Go through demo.py

# Demo
Custom functions Lab